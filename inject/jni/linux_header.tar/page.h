# ifdef __i386__
#  include "page_32.h"
# else
#  include "page_64.h"
# endif
